package com.example.urna;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UrnaApplication {

	public static void main(String[] args) {
		SpringApplication.run(UrnaApplication.class, args);
	}

}
